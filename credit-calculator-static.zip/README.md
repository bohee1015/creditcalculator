# 크레딧 계산기 (정적 HTML)

index.html 한 파일로 동작하는 버전입니다. (엑셀에서 추출한 장비/팁/단가가 코드에 포함됨)

## 사용
- index.html을 더블클릭하여 로컬에서 실행 가능
- 또는 GitHub Pages / Cloudflare Pages 같은 정적 호스팅에 올리면 URL로 공유 가능

## 주의
- 이 버전은 데이터가 코드에 박혀 있으므로, 장비/팁/단가가 바뀌면 다시 생성해야 합니다.
- 데이터가 자주 바뀌면 Google Apps Script 버전을 추천합니다.
